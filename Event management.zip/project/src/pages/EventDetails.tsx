import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Calendar, Clock, MapPin, Users, Share2, Bell } from 'lucide-react';
import { format, parseISO, differenceInMinutes } from 'date-fns';
import toast from 'react-hot-toast';
import { addToCalendar } from '../lib/notifications';
import { sendEventConfirmation } from '../lib/email';
import { useAuth } from '../contexts/AuthContext';
import RegistrationModal from '../components/RegistrationModal';

const EVENTS = [
  {
    id: '1',
    title: 'Web Development Workshop',
    description: 'Learn modern web development techniques with hands-on exercises.',
    location: 'Tech Hub - Room A',
    start_time: '2025-04-01T09:00:00',
    end_time: '2025-04-01T12:00:00',
    max_attendees: 30,
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97'
  },
  {
    id: '2',
    title: 'Data Science Fundamentals',
    description: 'Introduction to data analysis and machine learning concepts.',
    location: 'Innovation Center',
    start_time: '2025-04-02T14:00:00',
    end_time: '2025-04-02T17:00:00',
    max_attendees: 25,
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71'
  },
  {
    id: '3',
    title: 'UI/UX Design Workshop',
    description: 'Master the principles of user interface and experience design.',
    location: 'Design Studio',
    start_time: '2025-04-03T10:00:00',
    end_time: '2025-04-03T15:00:00',
    max_attendees: 20,
    image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0'
  },
  {
    id: '4',
    title: 'Mobile App Development',
    description: 'Build cross-platform mobile applications using React Native.',
    location: 'Tech Hub - Room B',
    start_time: '2025-04-04T13:00:00',
    end_time: '2025-04-04T16:00:00',
    max_attendees: 25,
    image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c'
  },
  {
    id: '5',
    title: 'Cloud Computing Essentials',
    description: 'Learn about cloud services and deployment strategies.',
    location: 'Virtual Training Room',
    start_time: '2025-04-05T11:00:00',
    end_time: '2025-04-05T14:00:00',
    max_attendees: 40,
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa'
  },
  {
    id: '6',
    title: 'Cybersecurity Workshop',
    description: 'Understanding security principles and best practices.',
    location: 'Security Lab',
    start_time: '2025-04-06T09:30:00',
    end_time: '2025-04-06T12:30:00',
    max_attendees: 20,
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b'
  },
  {
    id: '7',
    title: 'Artificial Intelligence Basics',
    description: 'Introduction to AI concepts and applications.',
    location: 'Innovation Center',
    start_time: '2025-04-07T15:00:00',
    end_time: '2025-04-07T18:00:00',
    max_attendees: 30,
    image: 'https://images.unsplash.com/photo-1555255707-c07966088b7b'
  },
  {
    id: '8',
    title: 'DevOps Practices',
    description: 'Learn about continuous integration and deployment.',
    location: 'Tech Hub - Room C',
    start_time: '2025-04-08T10:00:00',
    end_time: '2025-04-08T13:00:00',
    max_attendees: 25,
    image: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea'
  },
  {
    id: '9',
    title: 'Blockchain Technology',
    description: 'Understanding blockchain fundamentals and applications.',
    location: 'Virtual Training Room',
    start_time: '2025-04-09T14:00:00',
    end_time: '2025-04-09T17:00:00',
    max_attendees: 35,
    image: 'https://images.unsplash.com/photo-1639322537228-f710d846310a'
  },
  {
    id: '10',
    title: 'Project Management',
    description: 'Learn agile methodologies and project management tools.',
    location: 'Management Center',
    start_time: '2025-04-10T11:00:00',
    end_time: '2025-04-10T14:00:00',
    max_attendees: 30,
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978'
  }
];

export default function EventDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isRegistered, setIsRegistered] = useState(false);
  const [reminderSet, setReminderSet] = useState(false);
  const [showRegistrationModal, setShowRegistrationModal] = useState(false);

  const event = EVENTS.find(e => e.id === id);

  const handleAddToCalendar = async () => {
    if (!event) return;

    try {
      const calendarUrl = await addToCalendar(event);
      const link = document.createElement('a');
      link.href = calendarUrl;
      link.download = `${event.title}.ics`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(calendarUrl);
      toast.success('Event added to calendar');
    } catch (error) {
      console.error('Error adding to calendar:', error);
      toast.error('Failed to add event to calendar');
    }
  };

  const handleShare = async () => {
    if (!event) return;

    try {
      await navigator.share({
        title: event.title,
        text: event.description,
        url: window.location.href,
      });
    } catch (error) {
      console.error('Error sharing:', error);
      navigator.clipboard.writeText(window.location.href);
      toast.success('Link copied to clipboard');
    }
  };

  const handleRegister = () => {
    if (!user) {
      toast.error('Please sign in to register');
      navigate('/login');
      return;
    }
    setShowRegistrationModal(true);
  };

  const handleRegistrationConfirm = async () => {
    if (!event || !user) return;

    try {
      await sendEventConfirmation(user.id, event);
      setIsRegistered(true);
      setShowRegistrationModal(false);
      toast.success('Registration confirmed! Check your email for details.');
    } catch (error) {
      console.error('Registration error:', error);
      toast.error('Failed to complete registration');
      throw error;
    }
  };

  const handleSetReminder = () => {
    setReminderSet(true);
    toast.success('Reminder set! You will be notified before the event.');
  };

  if (!event) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Event not found</h2>
        <p className="text-gray-600 mb-4">The event you're looking for doesn't exist.</p>
        <button
          onClick={() => navigate('/')}
          className="text-blue-600 hover:text-blue-700 font-medium"
        >
          View all events
        </button>
      </div>
    );
  }

  const duration = differenceInMinutes(parseISO(event.end_time), parseISO(event.start_time));
  const hours = Math.floor(duration / 60);
  const minutes = duration % 60;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="aspect-w-16 aspect-h-9 relative">
          <img
            src={`${event.image}?auto=format&fit=crop&w=1200&q=80`}
            alt={event.title}
            className="w-full h-64 object-cover"
          />
        </div>
        <div className="p-8">
          <div className="flex justify-between items-start mb-6">
            <h1 className="text-3xl font-bold text-gray-900">{event.title}</h1>
            <div className="flex space-x-2">
              <button
                onClick={handleShare}
                className="p-2 text-gray-600 hover:text-blue-600 rounded-full hover:bg-gray-100"
                title="Share event"
              >
                <Share2 className="h-5 w-5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="space-y-4">
              <div className="flex items-center text-gray-600">
                <Calendar className="h-5 w-5 mr-3 text-blue-600" />
                <div>
                  <p className="font-medium">{format(parseISO(event.start_time), 'EEEE, MMMM d, yyyy')}</p>
                  <p className="text-sm">
                    {format(parseISO(event.start_time), 'h:mm a')} - {format(parseISO(event.end_time), 'h:mm a')}
                  </p>
                </div>
              </div>

              <div className="flex items-center text-gray-600">
                <Clock className="h-5 w-5 mr-3 text-blue-600" />
                <span>
                  {hours > 0 && `${hours} hour${hours > 1 ? 's' : ''}`}
                  {minutes > 0 && ` ${minutes} minute${minutes > 1 ? 's' : ''}`}
                </span>
              </div>

              <div className="flex items-center text-gray-600">
                <MapPin className="h-5 w-5 mr-3 text-blue-600" />
                <span>{event.location}</span>
              </div>

              <div className="flex items-center text-gray-600">
                <Users className="h-5 w-5 mr-3 text-blue-600" />
                <span>{event.max_attendees} spots available</span>
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
              <div className="space-y-3">
                <button
                  onClick={handleRegister}
                  disabled={isRegistered}
                  className={`w-full flex items-center justify-center px-4 py-2 rounded-md shadow-sm text-sm font-medium ${
                    isRegistered
                      ? 'bg-green-100 text-green-800 cursor-not-allowed'
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  {isRegistered ? 'Registered' : 'Register Now'}
                </button>

                <button
                  onClick={handleAddToCalendar}
                  className="w-full flex items-center justify-center px-4 py-2 border border-blue-600 rounded-md shadow-sm text-sm font-medium text-blue-600 bg-white hover:bg-blue-50"
                >
                  <Calendar className="h-5 w-5 mr-2" />
                  Add to Calendar
                </button>

                <button
                  onClick={handleSetReminder}
                  disabled={reminderSet}
                  className={`w-full flex items-center justify-center px-4 py-2 border rounded-md shadow-sm text-sm font-medium ${
                    reminderSet
                      ? 'border-green-600 text-green-600 bg-green-50 cursor-not-allowed'
                      : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Bell className="h-5 w-5 mr-2" />
                  {reminderSet ? 'Reminder Set' : 'Set Reminder'}
                </button>
              </div>
            </div>
          </div>

          <div className="prose max-w-none">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">About this event</h2>
            <div className="text-gray-600 whitespace-pre-line">{event.description}</div>
          </div>
        </div>
      </div>

      <RegistrationModal
        event={event}
        isOpen={showRegistrationModal}
        onClose={() => setShowRegistrationModal(false)}
        onConfirm={handleRegistrationConfirm}
      />
    </div>
  );
}