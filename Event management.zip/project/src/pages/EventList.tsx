import React, { useState } from 'react';
import { Calendar, MapPin, Users, Clock } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import toast from 'react-hot-toast';
import { addToCalendar } from '../lib/notifications';
import { sendEventConfirmation } from '../lib/email';
import RegistrationModal from '../components/RegistrationModal';

const EVENTS = [
  {
    id: '1',
    title: 'Web Development Workshop',
    description: 'Learn modern web development techniques with hands-on exercises.',
    location: 'Tech Hub - Room A',
    start_time: '2025-04-01T09:00:00',
    end_time: '2025-04-01T12:00:00',
    max_attendees: 30,
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97'
  },
  {
    id: '2',
    title: 'Data Science Fundamentals',
    description: 'Introduction to data analysis and machine learning concepts.',
    location: 'Innovation Center',
    start_time: '2025-04-02T14:00:00',
    end_time: '2025-04-02T17:00:00',
    max_attendees: 25,
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71'
  },
  {
    id: '3',
    title: 'UI/UX Design Workshop',
    description: 'Master the principles of user interface and experience design.',
    location: 'Design Studio',
    start_time: '2025-04-03T10:00:00',
    end_time: '2025-04-03T15:00:00',
    max_attendees: 20,
    image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0'
  },
  {
    id: '4',
    title: 'Mobile App Development',
    description: 'Build cross-platform mobile applications using React Native.',
    location: 'Tech Hub - Room B',
    start_time: '2025-04-04T13:00:00',
    end_time: '2025-04-04T16:00:00',
    max_attendees: 25,
    image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c'
  },
  {
    id: '5',
    title: 'Cloud Computing Essentials',
    description: 'Learn about cloud services and deployment strategies.',
    location: 'Virtual Training Room',
    start_time: '2025-04-05T11:00:00',
    end_time: '2025-04-05T14:00:00',
    max_attendees: 40,
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa'
  },
  {
    id: '6',
    title: 'Cybersecurity Workshop',
    description: 'Understanding security principles and best practices.',
    location: 'Security Lab',
    start_time: '2025-04-06T09:30:00',
    end_time: '2025-04-06T12:30:00',
    max_attendees: 20,
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b'
  },
  {
    id: '7',
    title: 'Artificial Intelligence Basics',
    description: 'Introduction to AI concepts and applications.',
    location: 'Innovation Center',
    start_time: '2025-04-07T15:00:00',
    end_time: '2025-04-07T18:00:00',
    max_attendees: 30,
    image: 'https://images.unsplash.com/photo-1555255707-c07966088b7b'
  },
  {
    id: '8',
    title: 'DevOps Practices',
    description: 'Learn about continuous integration and deployment.',
    location: 'Tech Hub - Room C',
    start_time: '2025-04-08T10:00:00',
    end_time: '2025-04-08T13:00:00',
    max_attendees: 25,
    image: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea'
  },
  {
    id: '9',
    title: 'Blockchain Technology',
    description: 'Understanding blockchain fundamentals and applications.',
    location: 'Virtual Training Room',
    start_time: '2025-04-09T14:00:00',
    end_time: '2025-04-09T17:00:00',
    max_attendees: 35,
    image: 'https://images.unsplash.com/photo-1639322537228-f710d846310a'
  },
  {
    id: '10',
    title: 'Project Management',
    description: 'Learn agile methodologies and project management tools.',
    location: 'Management Center',
    start_time: '2025-04-10T11:00:00',
    end_time: '2025-04-10T14:00:00',
    max_attendees: 30,
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978'
  }
];

export default function EventList() {
  const [selectedEvent, setSelectedEvent] = useState<typeof EVENTS[0] | null>(null);
  const [showRegistrationModal, setShowRegistrationModal] = useState(false);
  const [registrations, setRegistrations] = useState<Record<string, boolean>>({});

  const handleRegister = (event: typeof EVENTS[0]) => {
    setSelectedEvent(event);
    setShowRegistrationModal(true);
  };

  const handleRegistrationConfirm = async (email: string) => {
    if (!selectedEvent) return;

    try {
      // Generate calendar file
      const calendarUrl = await addToCalendar(selectedEvent);
      
      // Send confirmation email with calendar attachment
      await sendEventConfirmation(email, selectedEvent, calendarUrl);

      setRegistrations(prev => ({ ...prev, [selectedEvent.id]: true }));
      setShowRegistrationModal(false);
      setSelectedEvent(null);
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Upcoming Events</h1>
        <p className="text-lg text-gray-600">Register for our exciting events and workshops</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {EVENTS.map((event) => (
          <div
            key={event.id}
            className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
          >
            <div className="aspect-w-16 aspect-h-9 overflow-hidden">
              <img
                src={event.image}
                alt={event.title}
                className="w-full h-48 object-cover"
              />
            </div>
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-2">{event.title}</h2>
              <p className="text-gray-600 mb-4">{event.description}</p>
              
              <div className="space-y-2 text-sm text-gray-600 mb-6">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                  {format(parseISO(event.start_time), 'EEEE, MMMM d, yyyy')}
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-gray-400" />
                  {format(parseISO(event.start_time), 'h:mm a')} - {format(parseISO(event.end_time), 'h:mm a')}
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                  {event.location}
                </div>
                <div className="flex items-center">
                  <Users className="h-4 w-4 mr-2 text-gray-400" />
                  {event.max_attendees} spots available
                </div>
              </div>

              <button
                onClick={() => handleRegister(event)}
                disabled={registrations[event.id]}
                className={`w-full px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  registrations[event.id]
                    ? 'bg-green-100 text-green-800 cursor-not-allowed'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                {registrations[event.id] ? 'Registered' : 'Register Now'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {selectedEvent && (
        <RegistrationModal
          event={selectedEvent}
          isOpen={showRegistrationModal}
          onClose={() => {
            setShowRegistrationModal(false);
            setSelectedEvent(null);
          }}
          onConfirm={handleRegistrationConfirm}
        />
      )}
    </div>
  );
}