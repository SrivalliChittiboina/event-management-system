import { supabase } from './supabase';
import { format } from 'date-fns';
import ical from 'ical-generator';

export interface Event {
  id: string;
  title: string;
  description: string;
  location: string;
  start_time: string;
  end_time: string;
  max_attendees: number;
  agenda?: AgendaItem[];
  type: 'conference' | 'training' | 'workshop';
  organizer_id: string;
}

export interface AgendaItem {
  id: string;
  title: string;
  description: string;
  start_time: string;
  end_time: string;
  speaker?: string;
  location: string;
}

export async function addToCalendar(event: Event): Promise<string> {
  const cal = ical({
    events: [{
      start: new Date(event.start_time),
      end: new Date(event.end_time),
      summary: event.title,
      description: event.description,
      location: event.location,
    }],
  });

  const blob = new Blob([cal.toString()], { type: 'text/calendar' });
  return URL.createObjectURL(blob);
}

export async function checkVenueAvailability(
  location: string,
  startTime: string,
  endTime: string,
  eventId?: string
): Promise<boolean> {
  const { data, error } = await supabase
    .rpc('check_venue_availability', {
      venue_location: location,
      start_time: startTime,
      end_time: endTime,
      current_event_id: eventId || null
    });

  if (error) {
    console.error('Error checking venue availability:', error);
    throw new Error('Failed to check venue availability');
  }

  return data;
}

export async function getEventAgenda(eventId: string): Promise<AgendaItem[]> {
  const { data, error } = await supabase
    .from('agenda_items')
    .select('*')
    .eq('event_id', eventId)
    .order('start_time');

  if (error) {
    console.error('Error fetching agenda:', error);
    throw new Error('Failed to fetch event agenda');
  }

  return data || [];
}

export async function updateEventAgenda(
  eventId: string,
  agendaItems: Omit<AgendaItem, 'id'>[]
): Promise<void> {
  const { error } = await supabase
    .from('agenda_items')
    .upsert(
      agendaItems.map(item => ({
        ...item,
        event_id: eventId
      }))
    );

  if (error) {
    console.error('Error updating agenda:', error);
    throw new Error('Failed to update event agenda');
  }
}

export async function getEventCapacity(eventId: string): Promise<{
  registered: number;
  maximum: number;
}> {
  const { data, error } = await supabase
    .from('events')
    .select(`
      max_attendees,
      registrations!inner(status)
    `)
    .eq('id', eventId)
    .eq('registrations.status', 'confirmed')
    .single();

  if (error) {
    console.error('Error checking capacity:', error);
    throw new Error('Failed to check event capacity');
  }

  return {
    registered: data?.registrations?.length || 0,
    maximum: data?.max_attendees || 0
  };
}

export async function registerForEvent(
  eventId: string,
  userId: string
): Promise<{ success: boolean; status: 'confirmed' | 'waitlist' }> {
  const { data: capacity } = await getEventCapacity(eventId);
  
  const status = capacity.registered < capacity.maximum ? 'confirmed' : 'waitlist';

  const { error } = await supabase
    .from('registrations')
    .insert({
      event_id: eventId,
      user_id: userId,
      status
    });

  if (error) {
    console.error('Registration error:', error);
    throw new Error('Failed to register for event');
  }

  return {
    success: true,
    status
  };
}

export async function getUpcomingEvents(userId?: string): Promise<Event[]> {
  let query = supabase
    .from('events')
    .select(`
      *,
      agenda_items (*),
      registrations!inner(status)
    `)
    .gt('start_time', new Date().toISOString())
    .order('start_time');

  if (userId) {
    query = query.eq('registrations.user_id', userId);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching events:', error);
    throw new Error('Failed to fetch upcoming events');
  }

  return data || [];
}