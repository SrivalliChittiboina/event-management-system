import { parsePhoneNumber, isValidPhoneNumber } from 'libphonenumber-js';
import { supabase } from './supabase';

interface Event {
  title: string;
  description: string;
  location: string;
  start_time: string;
  end_time: string;
}

export function validatePhoneNumber(phone: string): boolean {
  try {
    // Ensure the number starts with +1
    if (!phone.startsWith('+1')) {
      return false;
    }

    // Remove +1 and check if remaining digits are exactly 10
    const digits = phone.slice(2).replace(/\D/g, '');
    if (digits.length !== 10) {
      return false;
    }

    return isValidPhoneNumber(phone, 'US');
  } catch (error) {
    return false;
  }
}

export function formatPhoneNumber(phone: string): string {
  try {
    // Ensure the number starts with +1
    const normalizedPhone = phone.startsWith('+1') ? phone : `+1${phone.replace(/\D/g, '')}`;
    const phoneNumber = parsePhoneNumber(normalizedPhone, 'US');
    return phoneNumber ? phoneNumber.format('E.164') : phone;
  } catch (error) {
    return phone;
  }
}

export async function sendEventConfirmationSMS(phone: string, event: Event) {
  if (!validatePhoneNumber(phone)) {
    throw new Error('Please enter a valid US phone number (+1 followed by 10 digits)');
  }

  const formattedPhone = formatPhoneNumber(phone);

  try {
    // Use the full URL with the correct path
    const functionUrl = new URL('/functions/v1/send-sms', supabase.supabaseUrl).toString();
    
    const maxRetries = 3;
    let lastError: Error | null = null;

    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        const response = await fetch(functionUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${supabase.supabaseKey}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Origin': window.location.origin
          },
          body: JSON.stringify({
            to: formattedPhone,
            event: {
              title: event.title,
              date: new Date(event.start_time).toLocaleDateString(),
              time: `${new Date(event.start_time).toLocaleTimeString()} - ${new Date(event.end_time).toLocaleTimeString()}`,
              location: event.location
            }
          }),
          mode: 'cors',
          credentials: 'omit'
        });

        // Handle non-JSON responses
        const contentType = response.headers.get('content-type');
        let errorData;
        
        if (contentType && contentType.includes('application/json')) {
          errorData = await response.json();
        } else {
          const text = await response.text();
          errorData = { error: text || `HTTP error! status: ${response.status}` };
        }

        if (!response.ok) {
          throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
        }

        if (!errorData.success) {
          throw new Error(errorData.error || 'Failed to send SMS');
        }

        return errorData;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error('Unknown error occurred');
        
        // Only retry on network errors or 5xx server errors
        if (error instanceof TypeError || (error instanceof Error && error.message.includes('status: 5'))) {
          if (attempt < maxRetries - 1) {
            await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, attempt)));
            continue;
          }
        }
        throw lastError;
      }
    }

    throw lastError || new Error('Failed to send SMS after multiple attempts');
  } catch (error) {
    console.error('Error sending confirmation SMS:', error);
    
    if (error instanceof TypeError && error.message === 'Failed to fetch') {
      throw new Error('Unable to connect to SMS service. Please try again later.');
    }
    
    if (error instanceof Error) {
      throw new Error(`Failed to send confirmation SMS: ${error.message}`);
    }
    
    throw new Error('Failed to send confirmation SMS. Please try again.');
  }
}