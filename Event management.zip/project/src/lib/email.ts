import { Resend } from 'resend';

const resend = new Resend(import.meta.env.VITE_RESEND_API_KEY);

interface Event {
  title: string;
  description: string;
  location: string;
  start_time: string;
  end_time: string;
}

export async function sendEventConfirmation(email: string, event: Event, calendarUrl: string) {
  if (!import.meta.env.VITE_RESEND_API_KEY) {
    throw new Error('Resend API key is not configured');
  }

  try {
    // First verify the email can be sent
    const response = await fetch('https://api.resend.com/validate', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email })
    });

    if (!response.ok) {
      throw new Error('Failed to validate email address');
    }

    // Send the email
    const { data, error } = await resend.emails.send({
      from: 'Sam\'s Events <onboarding@resend.dev>',
      to: [email],
      subject: `Registration Confirmed: ${event.title}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #1a56db; margin-bottom: 20px;">Registration Confirmed!</h1>
          
          <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h2 style="color: #111827; margin-top: 0;">${event.title}</h2>
            <p style="color: #4b5563; margin-bottom: 20px;">${event.description}</p>
            
            <div style="margin-top: 20px;">
              <p style="margin: 5px 0;"><strong>Date:</strong> ${new Date(event.start_time).toLocaleDateString()}</p>
              <p style="margin: 5px 0;"><strong>Time:</strong> ${new Date(event.start_time).toLocaleTimeString()} - ${new Date(event.end_time).toLocaleTimeString()}</p>
              <p style="margin: 5px 0;"><strong>Location:</strong> ${event.location}</p>
            </div>
          </div>
          
          <div style="margin-top: 20px; text-align: center;">
            <p style="margin-bottom: 15px;">Add this event to your calendar:</p>
            <a href="${calendarUrl}" 
               style="display: inline-block; background-color: #1a56db; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 500;">
              Add to Calendar
            </a>
          </div>
          
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; font-size: 14px; color: #6b7280; text-align: center;">
            <p>This email was sent by Sam's Events. Please do not reply to this email.</p>
          </div>
        </div>
      `
    });

    if (error) {
      console.error('Email sending error:', error);
      throw new Error(`Failed to send email: ${error.message}`);
    }

    if (!data?.id) {
      throw new Error('Failed to send email: No confirmation ID received');
    }

    return {
      success: true,
      message: 'Email sent successfully',
      id: data.id
    };
  } catch (error) {
    console.error('Error sending confirmation email:', error);
    
    // Check if it's a network error
    if (error instanceof TypeError && error.message === 'Failed to fetch') {
      throw new Error('Unable to connect to email service. Please try again later.');
    }
    
    // Handle other errors
    if (error instanceof Error) {
      throw new Error(`Failed to send confirmation email: ${error.message}`);
    }
    
    throw new Error('Failed to send confirmation email. Please try again.');
  }
}