/*
  # Event Management System Schema

  1. New Tables
    - `events`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `location` (text)
      - `start_time` (timestamptz)
      - `end_time` (timestamptz)
      - `max_attendees` (integer)
      - `created_by` (uuid, references auth.users)
      - `created_at` (timestamptz)

    - `registrations`
      - `id` (uuid, primary key)
      - `event_id` (uuid, references events)
      - `user_id` (uuid, references auth.users)
      - `status` (text: confirmed, cancelled, waitlist)
      - `calendar_added` (boolean)
      - `reminder_sent` (boolean)
      - `created_at` (timestamptz)

    - `notification_preferences`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `email_notifications` (boolean)
      - `calendar_sync` (boolean)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Drop existing functions, triggers, policies, and indexes
DROP FUNCTION IF EXISTS check_venue_availability(text, timestamptz, timestamptz);
DROP FUNCTION IF EXISTS prevent_venue_conflict() CASCADE;
DROP FUNCTION IF EXISTS check_registration_limit() CASCADE;
DROP POLICY IF EXISTS "Only authenticated users can view future events" ON events;
DROP POLICY IF EXISTS "Event creators can update their events" ON events;
DROP POLICY IF EXISTS "Users can create events" ON events;
DROP POLICY IF EXISTS "Users can view their registrations" ON registrations;
DROP POLICY IF EXISTS "Users can register for events" ON registrations;
DROP POLICY IF EXISTS "Users can update their registrations" ON registrations;
DROP POLICY IF EXISTS "Users can view their notification preferences" ON notification_preferences;
DROP POLICY IF EXISTS "Users can manage their notification preferences" ON notification_preferences;

-- Drop existing indexes
DROP INDEX IF EXISTS idx_events_start_time;
DROP INDEX IF EXISTS idx_events_location;
DROP INDEX IF EXISTS idx_events_created_by;
DROP INDEX IF EXISTS idx_registrations_event_id;
DROP INDEX IF EXISTS idx_registrations_user_id;
DROP INDEX IF EXISTS idx_registrations_status;

-- Create events table
CREATE TABLE IF NOT EXISTS events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  location text NOT NULL,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  max_attendees integer NOT NULL DEFAULT 0,
  created_by uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_dates CHECK (end_time > start_time)
);

-- Create registrations table
CREATE TABLE IF NOT EXISTS registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  status text NOT NULL CHECK (status IN ('confirmed', 'cancelled', 'waitlist')),
  calendar_added boolean DEFAULT false,
  reminder_sent boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  UNIQUE(event_id, user_id)
);

-- Create notification preferences table
CREATE TABLE IF NOT EXISTS notification_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL UNIQUE,
  email_notifications boolean DEFAULT true,
  calendar_sync boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Function to check venue availability
CREATE OR REPLACE FUNCTION check_venue_availability(
  location_param text,
  start_time_param timestamptz,
  end_time_param timestamptz
) RETURNS boolean AS $$
BEGIN
  RETURN NOT EXISTS (
    SELECT 1 FROM events
    WHERE location = location_param
    AND (
      (start_time_param, end_time_param) OVERLAPS (start_time, end_time)
    )
  );
END;
$$ LANGUAGE plpgsql;

-- Function to prevent venue conflicts
CREATE OR REPLACE FUNCTION prevent_venue_conflict()
RETURNS TRIGGER AS $$
BEGIN
  IF NOT check_venue_availability(NEW.location, NEW.start_time, NEW.end_time) THEN
    RAISE EXCEPTION 'Venue is already booked for this time period';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to check registration limit
CREATE OR REPLACE FUNCTION check_registration_limit()
RETURNS TRIGGER AS $$
BEGIN
  IF (
    SELECT COUNT(*) 
    FROM registrations 
    WHERE event_id = NEW.event_id 
    AND status = 'confirmed'
  ) >= (
    SELECT max_attendees 
    FROM events 
    WHERE id = NEW.event_id
  ) THEN
    NEW.status = 'waitlist';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER prevent_venue_conflict
  BEFORE INSERT OR UPDATE ON events
  FOR EACH ROW
  EXECUTE FUNCTION prevent_venue_conflict();

CREATE TRIGGER enforce_registration_limit
  BEFORE INSERT ON registrations
  FOR EACH ROW
  EXECUTE FUNCTION check_registration_limit();

-- Enable Row Level Security
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;

-- Policies for events
CREATE POLICY "Only authenticated users can view future events"
  ON events FOR SELECT
  TO authenticated
  USING (start_time > (now() - '1 day'::interval));

CREATE POLICY "Event creators can update their events"
  ON events FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can create events"
  ON events FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

-- Policies for registrations
CREATE POLICY "Users can view their registrations"
  ON registrations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can register for events"
  ON registrations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their registrations"
  ON registrations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policies for notification preferences
CREATE POLICY "Users can view their notification preferences"
  ON notification_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their notification preferences"
  ON notification_preferences FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_events_start_time ON events(start_time);
CREATE INDEX IF NOT EXISTS idx_events_location ON events(location);
CREATE INDEX IF NOT EXISTS idx_events_created_by ON events(created_by);
CREATE INDEX IF NOT EXISTS idx_registrations_event_id ON registrations(event_id);
CREATE INDEX IF NOT EXISTS idx_registrations_user_id ON registrations(user_id);
CREATE INDEX IF NOT EXISTS idx_registrations_status ON registrations(status);