/*
  # Event Management System Schema

  1. Tables
    - events: Store event information
    - registrations: Track event registrations
  
  2. Functions and Triggers
    - Venue conflict prevention
    - Registration limit handling
    - Automatic waitlist management

  3. Security
    - Row Level Security (RLS) enabled
    - Policies for authenticated users
*/

-- Create events table
CREATE TABLE IF NOT EXISTS events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  location text NOT NULL,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  max_attendees integer NOT NULL DEFAULT 0,
  created_by uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_dates CHECK (end_time > start_time)
);

-- Create registrations table
CREATE TABLE IF NOT EXISTS registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  status text NOT NULL CHECK (status IN ('confirmed', 'cancelled', 'waitlist')),
  calendar_added boolean DEFAULT false,
  reminder_sent boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  UNIQUE(event_id, user_id)
);

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS check_venue_availability(text, timestamptz, timestamptz);

-- Function to check venue availability
CREATE OR REPLACE FUNCTION check_venue_availability(
  venue_location text,
  start_time timestamptz,
  end_time timestamptz
) RETURNS boolean AS $$
BEGIN
  RETURN NOT EXISTS (
    SELECT 1 FROM events
    WHERE location = venue_location
    AND (
      (start_time, end_time) OVERLAPS (events.start_time, events.end_time)
    )
  );
END;
$$ LANGUAGE plpgsql;

-- Function to prevent venue conflicts
CREATE OR REPLACE FUNCTION prevent_venue_conflict()
RETURNS TRIGGER AS $$
BEGIN
  IF NOT check_venue_availability(NEW.location, NEW.start_time, NEW.end_time) THEN
    RAISE EXCEPTION 'Venue is already booked for this time period';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to check registration limit
CREATE OR REPLACE FUNCTION check_registration_limit()
RETURNS TRIGGER AS $$
BEGIN
  IF (
    SELECT COUNT(*) 
    FROM registrations 
    WHERE event_id = NEW.event_id 
    AND status = 'confirmed'
  ) >= (
    SELECT max_attendees 
    FROM events 
    WHERE id = NEW.event_id
  ) THEN
    NEW.status = 'waitlist';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS prevent_venue_conflict ON events;
DROP TRIGGER IF EXISTS enforce_registration_limit ON registrations;

-- Trigger for venue conflict prevention
CREATE TRIGGER prevent_venue_conflict
  BEFORE INSERT OR UPDATE ON events
  FOR EACH ROW
  EXECUTE FUNCTION prevent_venue_conflict();

-- Trigger for registration limit
CREATE TRIGGER enforce_registration_limit
  BEFORE INSERT ON registrations
  FOR EACH ROW
  EXECUTE FUNCTION check_registration_limit();

-- Enable Row Level Security
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE registrations ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Anyone can view events" ON events;
DROP POLICY IF EXISTS "Event creators can update their events" ON events;
DROP POLICY IF EXISTS "Users can create events" ON events;
DROP POLICY IF EXISTS "Users can view their registrations" ON registrations;
DROP POLICY IF EXISTS "Users can register for events" ON registrations;
DROP POLICY IF EXISTS "Users can update their registrations" ON registrations;

-- Create new policies for events
CREATE POLICY "Anyone can view events"
  ON events FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Event creators can update their events"
  ON events FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can create events"
  ON events FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

-- Create new policies for registrations
CREATE POLICY "Users can view their registrations"
  ON registrations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can register for events"
  ON registrations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their registrations"
  ON registrations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX idx_events_start_time ON events(start_time);
CREATE INDEX idx_events_location ON events(location);
CREATE INDEX idx_events_created_by ON events(created_by);
CREATE INDEX idx_registrations_event_id ON registrations(event_id);
CREATE INDEX idx_registrations_user_id ON registrations(user_id);
CREATE INDEX idx_registrations_status ON registrations(status);