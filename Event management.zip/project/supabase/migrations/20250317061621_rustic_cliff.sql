/*
  # Enhance Events System Security and Features

  1. Security Updates
    - Strengthen RLS policies for events and registrations
    - Add notification preferences table
    - Add venue availability checks

  2. New Features
    - Event notifications system
    - Calendar integration improvements
    - Venue conflict prevention
*/

-- Add notification preferences
CREATE TABLE IF NOT EXISTS notification_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  email_notifications boolean DEFAULT true,
  calendar_sync boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;

-- Notification preferences policies
CREATE POLICY "Users can view own notification preferences"
  ON notification_preferences
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notification preferences"
  ON notification_preferences
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own notification preferences"
  ON notification_preferences
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Add venue availability function
CREATE OR REPLACE FUNCTION check_venue_availability(
  venue_location text,
  start_time timestamptz,
  end_time timestamptz
) RETURNS boolean AS $$
BEGIN
  RETURN NOT EXISTS (
    SELECT 1 FROM events
    WHERE location = venue_location
    AND (
      (start_time, end_time) OVERLAPS (events.start_time, events.end_time)
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update events table policies
CREATE POLICY "Only authenticated users can view future events"
  ON events
  FOR SELECT
  TO authenticated
  USING (start_time > now() - interval '1 day');

-- Add trigger for venue conflict prevention
CREATE OR REPLACE FUNCTION prevent_venue_conflict()
RETURNS TRIGGER AS $$
BEGIN
  IF NOT check_venue_availability(NEW.location, NEW.start_time, NEW.end_time) THEN
    RAISE EXCEPTION 'Venue is already booked for this time period';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER check_venue_conflict
  BEFORE INSERT OR UPDATE ON events
  FOR EACH ROW
  EXECUTE FUNCTION prevent_venue_conflict();

-- Add registration status check
ALTER TABLE registrations
ADD COLUMN IF NOT EXISTS reminder_sent boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS calendar_added boolean DEFAULT false;

-- Update registration policies
CREATE POLICY "Users can only register for future events"
  ON registrations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM events
      WHERE events.id = event_id
      AND events.start_time > now()
      AND events.max_attendees > (
        SELECT COUNT(*) FROM registrations
        WHERE registrations.event_id = events.id
        AND registrations.status = 'confirmed'
      )
    )
  );