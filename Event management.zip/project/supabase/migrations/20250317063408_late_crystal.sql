/*
  # Create registrations table

  1. New Tables
    - `registrations`
      - `id` (uuid, primary key)
      - `event_id` (uuid, references events)
      - `user_id` (uuid, references auth.users)
      - `status` (text)
      - `registration_date` (timestamp)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `registrations` table
    - Add policies for authenticated users to:
      - Insert their own registrations
      - View their own registrations
    - Add unique constraint on event_id and user_id
*/

CREATE TABLE IF NOT EXISTS registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  status text NOT NULL CHECK (status IN ('confirmed', 'cancelled', 'waitlist')),
  registration_date timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE registrations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert their own registrations"
  ON registrations
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own registrations"
  ON registrations
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE UNIQUE INDEX registrations_event_user_idx ON registrations (event_id, user_id);