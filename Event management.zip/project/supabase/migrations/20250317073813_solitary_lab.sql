/*
  # Enhanced Event Management System

  1. New Features
    - Event types (conference, training, workshop)
    - Agenda items for detailed scheduling
    - Enhanced venue conflict prevention
    - Improved registration management

  2. New Tables
    - `agenda_items`: Store detailed event schedules
    - Enhanced `events` table with new fields
    - Additional registration features

  3. Security
    - Updated RLS policies
    - New functions for availability checking
*/

-- Add event types enum
CREATE TYPE event_type AS ENUM ('conference', 'training', 'workshop');

-- Enhance events table
ALTER TABLE events
ADD COLUMN type event_type NOT NULL DEFAULT 'conference',
ADD COLUMN organizer_id uuid REFERENCES auth.users(id) NOT NULL,
ADD COLUMN requires_approval boolean DEFAULT false,
ADD COLUMN registration_deadline timestamptz,
ADD COLUMN is_virtual boolean DEFAULT false,
ADD COLUMN virtual_meeting_link text,
ADD COLUMN prerequisites text[];

-- Create agenda items table
CREATE TABLE agenda_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  speaker text,
  location text NOT NULL,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_agenda_times CHECK (end_time > start_time)
);

-- Enable RLS on new table
ALTER TABLE agenda_items ENABLE ROW LEVEL SECURITY;

-- Update venue availability check
CREATE OR REPLACE FUNCTION check_venue_availability(
  venue_location text,
  start_time timestamptz,
  end_time timestamptz,
  current_event_id uuid DEFAULT NULL
) RETURNS boolean AS $$
BEGIN
  RETURN NOT EXISTS (
    SELECT 1 FROM events e
    LEFT JOIN agenda_items a ON a.event_id = e.id
    WHERE (
      (e.location = venue_location OR a.location = venue_location)
      AND (
        (start_time, end_time) OVERLAPS (e.start_time, e.end_time)
        OR (start_time, end_time) OVERLAPS (a.start_time, a.end_time)
      )
      AND (current_event_id IS NULL OR e.id != current_event_id)
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add registration enhancements
ALTER TABLE registrations
ADD COLUMN attendance_confirmed boolean DEFAULT false,
ADD COLUMN attendance_confirmed_at timestamptz,
ADD COLUMN notes text,
ADD COLUMN dietary_requirements text,
ADD COLUMN session_preferences jsonb;

-- Create indexes
CREATE INDEX idx_events_type ON events(type);
CREATE INDEX idx_events_organizer ON events(organizer_id);
CREATE INDEX idx_agenda_items_event ON agenda_items(event_id);
CREATE INDEX idx_agenda_items_time ON agenda_items(start_time, end_time);

-- RLS Policies for agenda items
CREATE POLICY "Anyone can view agenda items"
  ON agenda_items FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Event organizers can manage agenda items"
  ON agenda_items FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM events
      WHERE events.id = agenda_items.event_id
      AND events.organizer_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM events
      WHERE events.id = agenda_items.event_id
      AND events.organizer_id = auth.uid()
    )
  );

-- Update event policies
CREATE POLICY "Event organizers can manage their events"
  ON events FOR ALL
  TO authenticated
  USING (organizer_id = auth.uid())
  WITH CHECK (organizer_id = auth.uid());

-- Function to check registration deadline
CREATE OR REPLACE FUNCTION check_registration_deadline()
RETURNS TRIGGER AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM events
    WHERE id = NEW.event_id
    AND registration_deadline IS NOT NULL
    AND registration_deadline < now()
  ) THEN
    RAISE EXCEPTION 'Registration deadline has passed';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for registration deadline
CREATE TRIGGER enforce_registration_deadline
  BEFORE INSERT ON registrations
  FOR EACH ROW
  EXECUTE FUNCTION check_registration_deadline();