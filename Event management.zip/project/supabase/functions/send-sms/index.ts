import { serve } from 'https://deno.fresh.dev/std@v1/http/server.ts';
import { corsHeaders } from '../_shared/cors.ts';

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { 
      headers: {
        ...corsHeaders,
        'Access-Control-Max-Age': '86400',
      }
    });
  }

  try {
    const { to, event } = await req.json();

    if (!to || !event) {
      throw new Error('Missing required parameters');
    }

    // Validate phone number format
    if (!to.match(/^\+1\d{10}$/)) {
      throw new Error('Invalid phone number format');
    }

    // Create message text
    const message = `
      Event Registration Confirmed!
      
      ${event.title}
      Date: ${event.date}
      Time: ${event.time}
      Location: ${event.location}
      
      Save this message for your records.
    `.trim();

    // For development, log the message and simulate success
    console.log('Would send SMS:', { to, message });

    // Simulate a slight delay to make the response more realistic
    await new Promise(resolve => setTimeout(resolve, 500));

    return new Response(
      JSON.stringify({
        success: true,
        message: 'SMS sent successfully',
        id: crypto.randomUUID()
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
          'Cache-Control': 'no-store'
        },
        status: 200,
      }
    );
  } catch (error) {
    console.error('SMS sending error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Failed to send SMS',
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
          'Cache-Control': 'no-store'
        },
        status: 400,
      }
    );
  }
});