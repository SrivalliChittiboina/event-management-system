import { serve } from 'https://deno.fresh.dev/std@v1/http/server.ts';
import { corsHeaders } from '../_shared/cors.ts';

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { email, event, calendarUrl } = await req.json();

    // Log the request for debugging
    console.log('Processing registration for:', email);
    console.log('Event details:', event);

    // Send success response
    return new Response(
      JSON.stringify({
        success: true,
        message: 'Registration processed successfully',
        id: crypto.randomUUID()
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Registration error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Failed to process registration',
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
        status: 400,
      }
    );
  }
});